use std::f64::consts::PI;

// Function to calculate factorial
fn factorial(n: u32) -> f64 {
    if n == 0 {
        1.0
    } else {
        (1..=n).map(|x| x as f64).product()
    }
}

// Function to calculate sine using Taylor series
fn sin(x: f64, terms: u32) -> f64 {
    let mut result = 0.0;
    for n in 0..terms {
        let term = (-1.0_f64).powi(n as i32) * x.powi(2 * n as i32 + 1) / factorial(2 * n + 1);
        result += term;
    }
    result
}

// Function to calculate cosine using Taylor series
fn cos(x: f64, terms: u32) -> f64 {
    let mut result = 0.0;
    for n in 0..terms {
        let term = (-1.0_f64).powi(n as i32) * x.powi(2 * n as i32) / factorial(2 * n);
        result += term;
    }
    result
}

fn main() {
    // Number of terms in Taylor series (more terms = more accurate)
    let terms = 10;
    
    // Test angles in radians
    let angles = [0.0, PI/6.0, PI/4.0, PI/3.0, PI/2.0];
    
    println!("Taylor Series Approximation of Sine and Cosine");
    println!("--------------------------------------------");
    
    for angle in angles {
        let sin_value = sin(angle, terms);
        let cos_value = cos(angle, terms);
        
        println!("Angle: {:.2}π", angle/PI);
        println!("sin({:.2}π) ≈ {:.6}", angle/PI, sin_value);
        println!("cos({:.2}π) ≈ {:.6}", angle/PI, cos_value);
        println!();
    }
}
