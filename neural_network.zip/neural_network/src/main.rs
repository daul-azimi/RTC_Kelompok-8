use ndarray::{Array2, Axis};
use ndarray_rand::RandomExt;
use rand_distr::StandardNormal;
use rand::{seq::SliceRandom, thread_rng};
use csv::ReaderBuilder;
use std::error::Error;
use indicatif::{ProgressBar, ProgressStyle};
use eframe::{egui, epaint::Color32};
use egui_plot::{Line, Plot, PlotPoints};
use std::sync::{Arc, Mutex};
use std::thread;
use rfd::FileDialog;

fn relu(x: &Array2<f64>) -> Array2<f64> {
    x.mapv(|v| v.max(0.0))
}

fn relu_deriv(x: &Array2<f64>) -> Array2<f64> {
    x.mapv(|v| if v > 0.0 { 1.0 } else { 0.0 })
}

fn sigmoid(x: &Array2<f64>) -> Array2<f64> {
    x.mapv(|v| 1.0 / (1.0 + (-v).exp()))
}

fn binary_cross_entropy(y_pred: &Array2<f64>, y_true: &Array2<f64>) -> f64 {
    let eps = 1e-7;
    let y_pred_clipped = y_pred.mapv(|v| v.max(eps).min(1.0 - eps));
    let loss = y_true * &y_pred_clipped.mapv(|v| v.ln()) +
               (1.0 - y_true) * &y_pred_clipped.mapv(|v| (1.0 - v).ln());
    -loss.mean().unwrap()
}

fn accuracy(pred: &Array2<f64>, y_true: &Array2<f64>) -> f64 {
    let pred_bin = pred.mapv(|v| if v >= 0.5 { 1.0 } else { 0.0 });
    let correct = pred_bin.iter().zip(y_true.iter())
        .filter(|(p, y)| (*p - *y).abs() < 1e-6)
        .count();
    correct as f64 / y_true.nrows() as f64
}

fn load_data(path: &str) -> Result<(Array2<f64>, Array2<f64>), Box<dyn Error>> {
    let mut rdr = ReaderBuilder::new().has_headers(true).from_path(path)?;
    let mut features: Vec<Vec<f64>> = Vec::new();
    let mut labels: Vec<f64> = Vec::new();

    for result in rdr.records() {
        let record = result?;
        let vals: Result<Vec<f64>, _> = record.iter().map(|s| s.trim().parse::<f64>()).collect();
        if let Ok(vals) = vals {
            let (x, y) = vals.split_at(vals.len() - 1);
            features.push(x.to_vec());
            labels.push(y[0]);
        }
    }

    if features.is_empty() {
        return Err("CSV file is empty or has invalid format".into());
    }

    let feature_array = Array2::from_shape_vec((features.len(), features[0].len()), features.concat())?;
    let label_array = Array2::from_shape_vec((labels.len(), 1), labels)?;

    Ok((feature_array, label_array))
}

// Make constants configurable
struct NeuralNetworkConfig {
    epochs: usize,
    learning_rate: f64,
    hidden_neurons: usize,
    train_ratio: f64,
    log_interval: usize,
}

impl Default for NeuralNetworkConfig {
    fn default() -> Self {
        Self {
            epochs: 1000,
            learning_rate: 0.01,
            hidden_neurons: 16,
            train_ratio: 0.8,
            log_interval: 100,
        }
    }
}

struct NeuralNetworkApp {
    train_losses: Vec<f64>,
    test_losses: Vec<f64>,
    train_accs: Vec<f64>,
    test_accs: Vec<f64>,
    is_training: bool,
    training_thread: Option<thread::JoinHandle<()>>,
    training_data: Arc<Mutex<TrainingData>>,
    config: NeuralNetworkConfig,
    plot_filter: PlotFilter,
    error_message: Option<String>,
}

struct PlotFilter {
    loss_plot_range: (usize, usize),
    accuracy_plot_range: (usize, usize),
    auto_scale: bool,
    smoothing_factor: f64,
}

impl Default for PlotFilter {
    fn default() -> Self {
        Self {
            loss_plot_range: (0, 1000),
            accuracy_plot_range: (0, 1000),
            auto_scale: true,
            smoothing_factor: 0.0,
        }
    }
}

struct TrainingData {
    train_losses: Vec<f64>,
    test_losses: Vec<f64>,
    train_accs: Vec<f64>,
    test_accs: Vec<f64>,
    current_epoch: usize,
    is_complete: bool,
    final_test_accuracy: Option<f64>,
    correct_predictions: Option<usize>,
    total_test_data: Option<usize>,
    current_file: Option<String>,
    label_distribution: Option<std::collections::HashMap<String, usize>>,
    should_stop: bool,
}

impl Default for NeuralNetworkApp {
    fn default() -> Self {
        Self {
            train_losses: Vec::new(),
            test_losses: Vec::new(),
            train_accs: Vec::new(),
            test_accs: Vec::new(),
            is_training: false,
            training_thread: None,
            training_data: Arc::new(Mutex::new(TrainingData {
                train_losses: Vec::new(),
                test_losses: Vec::new(),
                train_accs: Vec::new(),
                test_accs: Vec::new(),
                current_epoch: 0,
                is_complete: false,
                final_test_accuracy: None,
                correct_predictions: None,
                total_test_data: None,
                current_file: None,
                label_distribution: None,
                should_stop: false,
            })),
            config: NeuralNetworkConfig::default(),
            plot_filter: PlotFilter::default(),
            error_message: None,
        }
    }
}

// Helper function for applying exponential smoothing to a vector of values
fn apply_smoothing(values: &[f64], smoothing_factor: f64) -> Vec<f64> {
    if smoothing_factor <= 0.0 || values.is_empty() {
        return values.to_vec();
    }
    
    let mut smoothed = Vec::with_capacity(values.len());
    if let Some(&first) = values.first() {
        smoothed.push(first);
        
        for i in 1..values.len() {
            let previous = smoothed[i-1];
            let current = values[i];
            let new_value = previous * smoothing_factor + current * (1.0 - smoothing_factor);
            smoothed.push(new_value);
        }
    }
    
    smoothed
}

impl eframe::App for NeuralNetworkApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        // Update data from the training thread
        if let Ok(data) = self.training_data.lock() {
            self.train_losses = data.train_losses.clone();
            self.test_losses = data.test_losses.clone();
            self.train_accs = data.train_accs.clone();
            self.test_accs = data.test_accs.clone();
            
            if data.is_complete {
                self.is_training = false;
                // Optionally join the thread if finished
                if let Some(handle) = self.training_thread.take() {
                    let _ = handle.join();
                }
            }
        }

        egui::CentralPanel::default().show(ctx, |ui| {
            ui.heading("Neural Network Training Visualization");
            
            // Create a layout with a left side panel for controls and a right side for plots
            egui::containers::Frame::none()
                .fill(egui::Color32::TRANSPARENT)
                .show(ui, |ui| {
                    ui.horizontal(|ui| {
                        // Left panel - controls
                        ui.vertical(|ui| {
                            ui.set_width(260.0); // Fixed width for control panel, reduced from 300
                            
                            // File selection section
                            ui.collapsing("Dataset Selection", |ui| {
                                if ui.button("Select CSV File").clicked() {
                                    if let Some(path) = FileDialog::new()
                                        .add_filter("CSV Files", &["csv"])
                                        .pick_file() 
                                    {
                                        // Validate the CSV file
                                        match load_data(&path.to_string_lossy()) {
                                            Ok((features, labels)) => {
                                                if let Ok(mut data) = self.training_data.lock() {
                                                    data.current_file = Some(path.to_string_lossy().into_owned());
                                                    // Reset training data when new file is selected
                                                    data.train_losses.clear();
                                                    data.test_losses.clear();
                                                    data.train_accs.clear();
                                                    data.test_accs.clear();
                                                    data.current_epoch = 0;
                                                    data.is_complete = false;
                                                    data.final_test_accuracy = None;
                                                    data.correct_predictions = None;
                                                    data.total_test_data = None;
                                                    // Label distribution
                                                    let mut label_dist = std::collections::HashMap::new();
                                                    for &label in labels.iter() {
                                                        let key = format!("{}", label);
                                                        *label_dist.entry(key).or_insert(0) += 1;
                                                    }
                                                    data.label_distribution = Some(label_dist);
                                                }
                                                self.error_message = None;
                                                
                                                // Show dataset info
                                                ui.label(format!("Dataset loaded successfully:"));
                                                ui.label(format!("Features: {} columns", features.ncols()));
                                                ui.label(format!("Samples: {} rows", features.nrows()));
                                            },
                                            Err(e) => {
                                                self.error_message = Some(format!("Error loading CSV file: {}", e));
                                            }
                                        }
                                    }
                                }
                                
                                if let Ok(data) = self.training_data.lock() {
                                    if let Some(file) = &data.current_file {
                                        ui.label(format!("Selected file: {}", file));
                                        if let Some(label_dist) = &data.label_distribution {
                                            ui.label(format!("Label distribution: {:?}", label_dist));
                                        }
                                    } else {
                                        ui.label("No file selected");
                                    }
                                }
                                
                                // Display error message if any
                                if let Some(error) = &self.error_message {
                                    ui.colored_label(Color32::RED, error);
                                }
                            });
                            
                            ui.add_space(10.0);
                            
                            // Parameter tuning section
                            if !self.is_training {
                                ui.collapsing("Training Parameters", |ui| {
                                    ui.horizontal(|ui| {
                                        ui.label("Epochs:")
                                            .on_hover_text("Jumlah iterasi training. Lebih banyak = model lebih belajar, tapi lebih lama.");
                                        ui.add(egui::DragValue::new(&mut self.config.epochs)
                                            .speed(10)
                                            .clamp_range(10..=10000));
                                    });
                                    
                                    ui.horizontal(|ui| {
                                        ui.label("Learning Rate:")
                                            .on_hover_text("Tingkat perubahan bobot setiap update. Nilai kecil = training lebih stabil, tapi lambat.");
                                        ui.add(egui::DragValue::new(&mut self.config.learning_rate)
                                            .speed(0.001)
                                            .clamp_range(0.0001..=1.0));
                                    });
                                    
                                    ui.horizontal(|ui| {
                                        ui.label("Hidden Neurons:")
                                            .on_hover_text("Jumlah neuron di hidden layer. Lebih banyak = model lebih kompleks.");
                                        ui.add(egui::DragValue::new(&mut self.config.hidden_neurons)
                                            .speed(1)
                                            .clamp_range(1..=128));
                                    });
                                    
                                    ui.horizontal(|ui| {
                                        ui.label("Train Ratio:")
                                            .on_hover_text("Proporsi data untuk training. Sisa data untuk testing.");
                                        ui.add(egui::DragValue::new(&mut self.config.train_ratio)
                                            .speed(0.01)
                                            .clamp_range(0.1..=0.9));
                                    });
                                });
                                
                                if ui.button("Start Training").clicked() {
                                    self.start_training();
                                }
                            } else {
                                // Show progress
                                if let Ok(data) = self.training_data.lock() {
                                    ui.label(format!("Training progress: Epoch {}/{}", data.current_epoch, self.config.epochs));
                                }
                            }
                            
                            // Display final results if available
                            if let Ok(data) = self.training_data.lock() {
                                if data.is_complete {
                                    if let (Some(acc), Some(correct), Some(total)) = (data.final_test_accuracy, data.correct_predictions, data.total_test_data) {
                                        ui.heading("Training Results");
                                        ui.label(format!("Total data testing: {}", total));
                                        ui.label(format!("Correctly predicted: {}", correct));
                                        ui.label(format!("Testing accuracy: {:.2}%", acc * 100.0));
                                    }
                                }
                            }
                            
                            ui.add_space(10.0);
                            
                            // Plot filtering options
                            ui.collapsing("Plot Settings", |ui| {
                                ui.checkbox(&mut self.plot_filter.auto_scale, "Auto Scale");
                                
                                if !self.plot_filter.auto_scale {
                                    ui.label("Loss Plot Range:");
                                    ui.horizontal(|ui| {
                                        ui.add(egui::DragValue::new(&mut self.plot_filter.loss_plot_range.0)
                                            .speed(1)
                                            .clamp_range(0..=self.train_losses.len().max(1) - 1));
                                        ui.label("to");
                                        ui.add(egui::DragValue::new(&mut self.plot_filter.loss_plot_range.1)
                                            .speed(1)
                                            .clamp_range(self.plot_filter.loss_plot_range.0 + 1..=self.train_losses.len().max(1)));
                                    });
                                    
                                    ui.label("Accuracy Plot Range:");
                                    ui.horizontal(|ui| {
                                        ui.add(egui::DragValue::new(&mut self.plot_filter.accuracy_plot_range.0)
                                            .speed(1)
                                            .clamp_range(0..=self.train_accs.len().max(1) - 1));
                                        ui.label("to");
                                        ui.add(egui::DragValue::new(&mut self.plot_filter.accuracy_plot_range.1)
                                            .speed(1)
                                            .clamp_range(self.plot_filter.accuracy_plot_range.0 + 1..=self.train_accs.len().max(1)));
                                    });
                                } else {
                                    // Update ranges automatically
                                    self.plot_filter.loss_plot_range = (0, self.train_losses.len().max(1));
                                    self.plot_filter.accuracy_plot_range = (0, self.train_accs.len().max(1));
                                }
                                
                                ui.horizontal(|ui| {
                                    ui.label("Smoothing:");
                                    ui.add(egui::Slider::new(&mut self.plot_filter.smoothing_factor, 0.0..=0.99)
                                        .text("factor"));
                                });
                            });

                            if self.is_training {
                                if let Ok(data) = self.training_data.lock() {
                                    let progress = data.current_epoch as f32 / self.config.epochs as f32;
                                    ui.add(egui::ProgressBar::new(progress).show_percentage());
                                }
                                if ui.button("Stop Training").on_hover_text("Hentikan training sebelum selesai").clicked() {
                                    if let Ok(mut data) = self.training_data.lock() {
                                        data.should_stop = true;
                                    }
                                }
                            }
                        });
                        
                        // Right panel - plots
                        ui.vertical(|ui| {
                            // Display training graphs
                            ui.heading("Training Metrics");
                            
                            // Center the grid horizontally
                            ui.add_space(10.0);
                            ui.horizontal_centered(|ui| {
                                let plot_width = 600.0;
                                let plot_height = 400.0;
                                egui::Grid::new("graphs_grid")
                                    .num_columns(2)
                                    .spacing([20.0, 20.0])
                                    .min_col_width(400.0)
                                    .show(ui, |ui| {
                                        // First row: Loss graphs
                                        ui.vertical(|ui| {
                                            ui.heading("Training Loss");
                                            Plot::new("training_loss_plot")
                                                .height(plot_height)
                                                .width(plot_width)
                                                .show_axes([true, true])
                                                .legend(egui_plot::Legend::default())
                                                .set_margin_fraction(egui::Vec2::new(0.1, 0.1))
                                                .show(ui, |plot_ui| {
                                                    if !self.train_losses.is_empty() {
                                                        let filtered_losses = if self.plot_filter.auto_scale {
                                                            self.train_losses.clone()
                                                        } else {
                                                            let start = self.plot_filter.loss_plot_range.0.min(self.train_losses.len().saturating_sub(1));
                                                            let end = self.plot_filter.loss_plot_range.1.min(self.train_losses.len());
                                                            self.train_losses[start..end].to_vec()
                                                        };
                                                        let smoothed_losses = apply_smoothing(&filtered_losses, self.plot_filter.smoothing_factor);
                                                        let points: PlotPoints = (0..smoothed_losses.len())
                                                            .map(|i| [i as f64, smoothed_losses[i]])
                                                            .collect();
                                                        plot_ui.line(Line::new(points)
                                                            .color(Color32::from_rgb(0, 0, 255))
                                                            .width(3.0)
                                                            .name("Training Loss"));
                                                    }
                                                });
                                        });
                                        ui.vertical(|ui| {
                                            ui.heading("Testing Loss");
                                            Plot::new("testing_loss_plot")
                                                .height(plot_height)
                                                .width(plot_width)
                                                .show_axes([true, true])
                                                .legend(egui_plot::Legend::default())
                                                .set_margin_fraction(egui::Vec2::new(0.1, 0.1))
                                                .show(ui, |plot_ui| {
                                                    if !self.test_losses.is_empty() {
                                                        let filtered_losses = if self.plot_filter.auto_scale {
                                                            self.test_losses.clone()
                                                        } else {
                                                            let start = self.plot_filter.loss_plot_range.0.min(self.test_losses.len().saturating_sub(1));
                                                            let end = self.plot_filter.loss_plot_range.1.min(self.test_losses.len());
                                                            self.test_losses[start..end].to_vec()
                                                        };
                                                        let smoothed_losses = apply_smoothing(&filtered_losses, self.plot_filter.smoothing_factor);
                                                        let points: PlotPoints = (0..smoothed_losses.len())
                                                            .map(|i| [i as f64, smoothed_losses[i]])
                                                            .collect();
                                                        plot_ui.line(Line::new(points)
                                                            .color(Color32::from_rgb(255, 0, 0))
                                                            .width(3.0)
                                                            .name("Testing Loss"));
                                                    }
                                                });
                                        });
                                        ui.end_row();
                                        // Second row: Accuracy graphs
                                        ui.vertical(|ui| {
                                            ui.heading("Training Accuracy");
                                            Plot::new("training_accuracy_plot")
                                                .height(plot_height)
                                                .width(plot_width)
                                                .show_axes([true, true])
                                                .legend(egui_plot::Legend::default())
                                                .set_margin_fraction(egui::Vec2::new(0.1, 0.1))
                                                .show(ui, |plot_ui| {
                                                    if !self.train_accs.is_empty() {
                                                        let filtered_accs = if self.plot_filter.auto_scale {
                                                            self.train_accs.clone()
                                                        } else {
                                                            let start = self.plot_filter.accuracy_plot_range.0.min(self.train_accs.len().saturating_sub(1));
                                                            let end = self.plot_filter.accuracy_plot_range.1.min(self.train_accs.len());
                                                            self.train_accs[start..end].to_vec()
                                                        };
                                                        let smoothed_accs = apply_smoothing(&filtered_accs, self.plot_filter.smoothing_factor);
                                                        let points: PlotPoints = (0..smoothed_accs.len())
                                                            .map(|i| [i as f64, smoothed_accs[i]])
                                                            .collect();
                                                        plot_ui.line(Line::new(points)
                                                            .color(Color32::from_rgb(0, 255, 0))
                                                            .width(3.0)
                                                            .name("Training Accuracy"));
                                                    }
                                                });
                                        });
                                        ui.vertical(|ui| {
                                            ui.heading("Testing Accuracy");
                                            Plot::new("testing_accuracy_plot")
                                                .height(plot_height)
                                                .width(plot_width)
                                                .show_axes([true, true])
                                                .legend(egui_plot::Legend::default())
                                                .set_margin_fraction(egui::Vec2::new(0.1, 0.1))
                                                .show(ui, |plot_ui| {
                                                    if !self.test_accs.is_empty() {
                                                        let filtered_accs = if self.plot_filter.auto_scale {
                                                            self.test_accs.clone()
                                                        } else {
                                                            let start = self.plot_filter.accuracy_plot_range.0.min(self.test_accs.len().saturating_sub(1));
                                                            let end = self.plot_filter.accuracy_plot_range.1.min(self.test_accs.len());
                                                            self.test_accs[start..end].to_vec()
                                                        };
                                                        let smoothed_accs = apply_smoothing(&filtered_accs, self.plot_filter.smoothing_factor);
                                                        let points: PlotPoints = (0..smoothed_accs.len())
                                                            .map(|i| [i as f64, smoothed_accs[i]])
                                                            .collect();
                                                        plot_ui.line(Line::new(points)
                                                            .color(Color32::from_rgb(255, 0, 255))
                                                            .width(3.0)
                                                            .name("Testing Accuracy"));
                                                    }
                                                });
                                        });
                                    });
                            });
                        });
                    });
                });
            
            // Add developer signature at the bottom with some spacing
            ui.add_space(20.0);
            ui.with_layout(egui::Layout::bottom_up(egui::Align::Center), |ui| {
                ui.label(
                    egui::RichText::new("Developed by Mukhamad Daul Azimi")
                        .italics()
                        .text_style(egui::TextStyle::Heading)
                        .size(18.0)
                        .strong()
                );
            });
        });
        
        // Request continuous update while training
        if self.is_training {
            ctx.request_repaint();
        }
    }
}

impl NeuralNetworkApp {
    fn start_training(&mut self) {
        // Cegah double training
        if self.is_training {
            // Optionally join the previous thread if it exists and is finished
            if let Some(handle) = self.training_thread.take() {
                let _ = handle.join();
            } else {
                return;
            }
        }

        let training_data = self.training_data.clone();
        let config = self.config.clone();

        // Check if a file is selected before starting training
        let has_file = {
            let data = training_data.lock().unwrap();
            data.current_file.is_some()
        };

        if !has_file {
            println!("Please select a CSV file first");
            return;
        }

        // Reset data training sebelum mulai training baru
        if let Ok(mut data) = training_data.lock() {
            data.train_losses.clear();
            data.test_losses.clear();
            data.train_accs.clear();
            data.test_accs.clear();
            data.current_epoch = 0;
            data.is_complete = false;
            data.final_test_accuracy = None;
            data.correct_predictions = None;
            data.total_test_data = None;
        }

        self.is_training = true;
        self.training_thread = Some(thread::spawn(move || {
            if let Err(e) = run_training(training_data, config) {
                eprintln!("Training error: {}", e);
            }
        }));
    }
}

// Make config cloneable
impl Clone for NeuralNetworkConfig {
    fn clone(&self) -> Self {
        Self {
            epochs: self.epochs,
            learning_rate: self.learning_rate,
            hidden_neurons: self.hidden_neurons,
            train_ratio: self.train_ratio,
            log_interval: self.log_interval,
        }
    }
}

fn run_training(training_data: Arc<Mutex<TrainingData>>, config: NeuralNetworkConfig) -> Result<(), Box<dyn Error>> {
    let file_path = {
        let data = training_data.lock().unwrap();
        data.current_file.as_ref().ok_or("No file selected")?.clone()
    };

    // Load data from the selected file
    let (features, labels) = load_data(&file_path)?;
    let (n_samples, n_features) = features.dim();

    let mut indices: Vec<usize> = (0..n_samples).collect();
    let mut rng = thread_rng();
    indices.shuffle(&mut rng);

    let train_size = (config.train_ratio * n_samples as f64) as usize;
    let train_idx = &indices[..train_size];
    let test_idx = &indices[train_size..];

    let x_train = features.select(Axis(0), train_idx);
    let y_train = labels.select(Axis(0), train_idx);
    let x_test = features.select(Axis(0), test_idx);
    let y_test = labels.select(Axis(0), test_idx);

    let mut w1 = Array2::random_using((n_features, config.hidden_neurons), StandardNormal, &mut rng);
    let mut b1 = Array2::zeros((1, config.hidden_neurons));
    let mut w2 = Array2::random_using((config.hidden_neurons, 1), StandardNormal, &mut rng);
    let mut b2 = Array2::zeros((1, 1));

    let mut train_losses = Vec::new();
    let mut test_losses = Vec::new();
    let mut train_accs = Vec::new();
    let mut test_accs = Vec::new();

    let pb = ProgressBar::new(config.epochs as u64);
    pb.set_style(
        ProgressStyle::with_template("[{elapsed_precise}] [{bar:40.cyan/blue}] {pos}/{len} Epochs | Loss: {msg}")
            .unwrap()
            .progress_chars("##-"),
    );

    // Declare y_test_pred before the loop for later use
    let mut y_test_pred: Option<Array2<f64>> = None;

    for epoch in 0..config.epochs {
        let z1 = x_train.dot(&w1) + &b1;
        let a1 = relu(&z1);
        let z2 = a1.dot(&w2) + &b2;
        let y_pred = sigmoid(&z2);

        let loss = binary_cross_entropy(&y_pred, &y_train);
        train_losses.push(loss);
        train_accs.push(accuracy(&y_pred, &y_train));

        // Test pass
        let z1_test = x_test.dot(&w1) + &b1;
        let a1_test = relu(&z1_test);
        let z2_test = a1_test.dot(&w2) + &b2;
        y_test_pred = Some(sigmoid(&z2_test)); // Store test prediction for later

        test_losses.push(binary_cross_entropy(&y_test_pred.as_ref().unwrap(), &y_test));
        test_accs.push(accuracy(&y_test_pred.as_ref().unwrap(), &y_test));

        // Backpropagation
        let dz2 = &y_pred - &y_train;
        let dw2 = a1.t().dot(&dz2) / train_size as f64;
        let db2 = dz2.sum_axis(Axis(0)) / train_size as f64;
        let da1 = dz2.dot(&w2.t());
        let dz1 = da1 * relu_deriv(&z1);
        let dw1 = x_train.t().dot(&dz1) / train_size as f64;
        let db1 = dz1.sum_axis(Axis(0)) / train_size as f64;

        w1 -= &(dw1 * config.learning_rate);
        b1 -= &(db1 * config.learning_rate);
        w2 -= &(dw2 * config.learning_rate);
        b2 -= &(db2 * config.learning_rate);

        if epoch % config.log_interval == 0 {
            println!("Epoch {} | Train Loss: {:.4} | Test Loss: {:.4}", epoch, loss, test_losses.last().unwrap());
        }

        // Update the training data for UI
        if let Ok(mut data) = training_data.lock() {
            data.train_losses = train_losses.clone();
            data.test_losses = test_losses.clone();
            data.train_accs = train_accs.clone();
            data.test_accs = test_accs.clone();
            data.current_epoch = epoch + 1;
        }

        pb.set_message(format!("{:.4}", loss));
        pb.inc(1);

        // Cek flag stop
        if let Ok(data) = training_data.lock() {
            if data.should_stop {
                break;
            }
        }
    }

    pb.finish_with_message("Training complete");

    // Calculate final testing accuracy
    if let Some(test_pred) = y_test_pred {
        let final_test_pred_bin = test_pred.mapv(|v| if v >= 0.5 { 1.0 } else { 0.0 });
        let final_accuracy = accuracy(&final_test_pred_bin, &y_test);
        let correct_predictions = final_test_pred_bin.iter()
            .zip(y_test.iter())
            .filter(|(p, y)| (*p - *y).abs() < 1e-6)
            .count();

        println!("\n✅ Total data testing: {}", y_test.nrows());
        println!("🎯 Benar terprediksi: {}", correct_predictions);
        println!("📊 Akurasi testing: {:.2}%", final_accuracy * 100.0);
        
        // Update final results
        if let Ok(mut data) = training_data.lock() {
            data.is_complete = true;
            data.final_test_accuracy = Some(final_accuracy);
            data.correct_predictions = Some(correct_predictions);
            data.total_test_data = Some(y_test.nrows());
        }
    }

    Ok(())
}

fn main() -> Result<(), Box<dyn Error>> {
    let options = eframe::NativeOptions {
        viewport: eframe::egui::ViewportBuilder::default()
            .with_inner_size([1280.0, 900.0]), // Increase default window size
        ..Default::default()
    };
    
    eframe::run_native(
        "Neural Network Training Visualization",
        options,
        Box::new(|_cc| Box::new(NeuralNetworkApp::default())),
    )?;
    
    Ok(())
}