use std::f32::consts::PI;
use std::sync::LazyLock;
use std::io::{self, Write};

const TABLE_SIZE: usize = 360;

// Lookup table untuk sine dan cosine (dalam derajat 0..359)
pub static SIN_TABLE: LazyLock<[f32; TABLE_SIZE]> = LazyLock::new(|| {
    let mut table = [0.0; TABLE_SIZE];
    for i in 0..TABLE_SIZE {
        table[i] = (i as f32 * PI / 180.0).sin();
    }
    table
});

pub static COS_TABLE: LazyLock<[f32; TABLE_SIZE]> = LazyLock::new(|| {
    let mut table = [0.0; TABLE_SIZE];
    for i in 0..TABLE_SIZE {
        table[i] = (i as f32 * PI / 180.0).cos();
    }
    table
});

fn lookup_sin(degrees: usize) -> f32 {
    SIN_TABLE[degrees % TABLE_SIZE]
}

fn lookup_cos(degrees: usize) -> f32 {
    COS_TABLE[degrees % TABLE_SIZE]
}

fn main() {
    println!("Masukkan 'sin <sudut>' atau 'cos <sudut>' (sudut dalam derajat, 0-359):");
    println!("Ketik 'exit' atau 'quit' untuk keluar.");
    loop {
        print!("> ");
        io::stdout().flush().unwrap();
        let mut input = String::new();
        if io::stdin().read_line(&mut input).is_err() {
            println!("Error membaca input.");
            continue;
        }
        let input = input.trim();
        if input == "exit" || input == "quit" {
            println!("Program berhenti.");
            break;
        }
        let parts: Vec<&str> = input.split_whitespace().collect();
        if parts.len() != 2 {
            println!("Format tidak valid. Gunakan 'sin <sudut>' atau 'cos <sudut>'.");
            continue;
        }
        let func = parts[0];
        let degrees: usize = match parts[1].parse() {
            Ok(n) => n,
            Err(_) => {
                println!("Sudut harus berupa angka.");
                continue;
            }
        };
        match func {
            "sin" => println!("sin({}) = {:.6}", degrees, lookup_sin(degrees)),
            "cos" => println!("cos({}) = {:.6}", degrees, lookup_cos(degrees)),
            _ => println!("Fungsi tidak valid. Gunakan 'sin' atau 'cos'."),
        }
    }
}
